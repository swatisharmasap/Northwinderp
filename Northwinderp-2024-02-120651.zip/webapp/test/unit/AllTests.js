sap.ui.define([
	"sapcom/northwinderp/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
