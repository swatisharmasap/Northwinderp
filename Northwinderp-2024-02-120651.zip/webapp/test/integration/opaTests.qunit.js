/* global QUnit */

sap.ui.require(["sap/com/northwinderp/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
